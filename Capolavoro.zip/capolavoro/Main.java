package capolavoro;

/**
 * @author SASSO ALESSANDRO ITT "SEN.O.JANNUZZI" - ANDRIA
 */
import java.util.*;

public class Main {
	static Scanner in;
	public static float valutazioneRosa;

	public static void main(String[] args) {
		in = new Scanner(System.in);
		Calciatore calciatori[] = new Calciatore[25];
		Squadra squadre[] = new Squadra[20];
		Calciatore titolari[] = new Calciatore[11];
		Calciatore portieri[] = new Calciatore[3];
		Calciatore difensori[] = new Calciatore[8];
		Calciatore centrocampisti[] = new Calciatore[8];
		Calciatore attaccanti[] = new Calciatore[6];
		System.out.println("Benvenuto nella creazione di una società partendo dalle basi");
		System.out.println("Seguirai i passi che ti permetteranno di creare una squadra di calcio");
		System.out.println(
				"Il primo passo quindi è ovviamente fondare la societa,una squadra che proverà a imporsi sul territorio nazionale,\npremi invio per la creazione");
		Societa s = fondaSocieta();
		System.out.println("\nIn breve questa è la società che hai appena fondato:");
		visualizzaSocieta(s);
		System.out.println(
				"\nOgni squadra ha bisogno di un allenatore che esprima il proprio gioco per portare risultati e divertimento ai propri tifosi");
		Allenatore al = inserisciAllenatore();
		System.out.println("La tua squadra di 25 giocatori sarà generata automaticamente");
		generaSquadra(calciatori, portieri, difensori, centrocampisti, attaccanti);
		System.out.println("\nPremi invio per visualizzare l'hub rosa,ossia la lista del tuo team");
		in.nextLine();
		visualizzaRosa(calciatori, portieri, difensori, centrocampisti, attaccanti);
		System.out.println("\nSquadra guidata da:");
		visualizzaAllenatore(al);
		System.out.println(
				"\nMa prima di iniziare la squadra neccessita di sapere con che modulo e titolari giocherai questa stagione");
		selezionaFormazione(portieri, difensori, centrocampisti, attaccanti, titolari, calciatori);
		System.out.println("\nLa tua squadra competerà in un campionato a noi conosciuto,la nostra amata Serie A");
		caricaSerieA(squadre, s);
		System.out.println("Riepiloghiamo le tue scelte sull'undici titolare");
		vediFormazione(titolari);
		System.out.println(
				"\nPremi invio per visualizzare la classifica iniziale, in modo tale da vedere i tuoi avversari");
		in.nextLine();
		visualizzaClassifica(squadre);
		System.out.println(
				"\nDopo i preparativi ora sei pronto per iniziare la ,nuova stagione 2023-2024 al meglio,premi invio per iniziare, verrà mostrato tutto il calendario,diviso in andata e ritorno");
		in.nextLine();
		simulaCampionato(squadre);
		System.out.println(
				"Questa era l'ultima giornata di campionato,ora premi invio per scoprire in che zona della classifica ti trovi");
		in.nextLine();
		vediClassifica(squadre);
	}

	public static void generaSquadra(Calciatore calciatori[], Calciatore portieri[], Calciatore difensori[],
			Calciatore centrocampisti[], Calciatore attaccanti[]) {
		int contP = 0, contD = 0, contC = 0, contA = 0;
		String ruolo = null;
		int eta, numero, valutazione;
		float valore;
		int maglie[] = new int[25];
		String[] nomi = { "Francesco", "Alessandro", "Andrea", "Lorenzo", "Matteo", "Leonardo", "Gabriele", "Riccardo",
				"Davide", "Marco", "Giacomo", "Simone", "Luca", "Federico", "Antonio", "Giovanni", "Giuseppe", "Paolo",
				"Filippo", "Alberto", "Massimo", "Stefano", "Michele", "Enrico", "Daniele" };
		String[] cognomi = { "Rossi", "Russo", "Ferrari", "Esposito", "Bianchi", "Romano", "Colombo", "Ricci", "Marino",
				"Greco", "Bruno", "Gallo", "Conti", "De Luca", "Mancini", "Costa", "Giordano", "Rizzo", "Lombardi",
				"Moretti", "Barbieri", "Fontana", "Santoro", "Mariani", "Rinaldi" };

		for (int i = 0; i < calciatori.length; i++) {
			int generaRuolo = (int) (Math.random() * 4);
			switch (generaRuolo) {
			case 0:
				ruolo = "portiere";
				break;
			case 1:
				ruolo = "difensore";
				break;
			case 2:
				ruolo = "centrocampista";
				break;
			case 3:
				ruolo = "attaccante";
				break;
			}

			eta = (int) (Math.random() * 25) + 16;

			boolean trovato = false;
			do {
				trovato = false;
				numero = (int) (Math.random() * 99) + 1;
				for (int j = 0; j < maglie.length; j++) {
					if (numero == maglie[j]) {
						trovato = true;
					}
				}
			} while (trovato == true);
			valutazione = (int) (Math.random() * 44) + 48;
			valore = 0;
			int utile = 50;
			double molGiovane = 0.5;
			double indGiovane = 0.07;
			double molEsperto = 0.4;
			double indEsperto = 0.08;
			double molVeterano = 0.25;
			double indVeterano = 0.09;
			if (eta >= 16 && eta <= 25) {
				valore = (float) ((utile - eta) * indGiovane * valutazione * molGiovane);
			} else if (eta > 25 && eta < 33) {
				valore = (float) ((utile - eta) * indEsperto * valutazione * molEsperto);
			} else {
				valore = (float) ((utile - eta) * indVeterano * valutazione * molVeterano);
			}

			String nome = nomi[(int) (Math.random() * nomi.length)];
			String cognome = cognomi[(int) (Math.random() * cognomi.length)];

			switch (ruolo) {
			case "portiere":
				if (contP < 3) {
					portieri[contP] = new Calciatore(nome, cognome, ruolo, numero, eta, valutazione, valore);
					calciatori[i] = portieri[contP];
					contP++;
				} else
					i--;
				break;
			case "difensore":
				if (contD < 8) {
					difensori[contD] = new Calciatore(nome, cognome, ruolo, numero, eta, valutazione, valore);
					calciatori[i] = difensori[contD];
					contD++;
				} else
					i--;
				break;
			case "centrocampista":
				if (contC < 8) {
					centrocampisti[contC] = new Calciatore(nome, cognome, ruolo, numero, eta, valutazione, valore);
					calciatori[i] = centrocampisti[contC];
					contC++;
				} else
					i--;
				break;
			case "attaccante":
				if (contA < 6) {
					attaccanti[contA] = new Calciatore(nome, cognome, ruolo, numero, eta, valutazione, valore);
					calciatori[i] = attaccanti[contA];
					contA++;
				} else
					i--;
				break;
			}
		}
	}

	public static Societa fondaSocieta() {
		boolean err = false;
		String nome = null, soprannome = null, sede = null, stadio = null;
		int capienzaStadio = 0;
		do {
			err = false;
			try {
				in.nextLine();
				System.out.println("Inserisci il nome della tua squadra:");
				nome = in.nextLine();
				System.out.println("Inserisci il soprannome della squadra:");
				soprannome = in.nextLine();
				System.out.print("Inserisci la sede della squadra:");
				System.out.println("");
				sede = in.nextLine();
				System.out.println("Inserisci il nome dello stadio:");
				stadio = in.nextLine();
				do {
					System.out.println("Inserisci la capienza dello stadio:");
					capienzaStadio = in.nextInt();
				} while (capienzaStadio <= 0);
			} catch (Exception e) {
				System.err.println(e);
				err = true;
			}
		} while (err == true);
		return new Societa(nome, soprannome, sede, stadio, capienzaStadio);
	}

	public static void visualizzaSocieta(Societa s) {
		System.out.println("Nome società: " + s.getNome());
		System.out.println("Soprannome società: " + s.getSoprannome());
		System.out.println("Sede: " + s.getSede());
		System.out.println("Stadio: " + s.getStadio());
		System.out.println("Capienza stadio: " + s.getCapienzaStadio());
	}

	public static Allenatore inserisciAllenatore() {
		int eta = 0, esperienza = 0;
		String nome = null, cognome = null;
		boolean err = false;
		do {
			err = false;
			try {
				in.nextLine();
				System.out.println("Inserisci nome allenatore:");
				nome = in.nextLine();
				System.out.println("Inserisci il cognome dell'allenatore");
				cognome = in.nextLine();
				do {
					System.out.println("Inserisci l'eta' dell'allenatore (tra i 23 e 80):");
					eta = in.nextInt();
				} while (eta < 23 || eta > 80);
				boolean possibile = true;
				do {
					possibile = true;
					System.out.println("Inserisci gli anni di esperienza da allenatore:");
					esperienza = in.nextInt();
					int diff = eta - esperienza;
					if (diff < 23) {
						System.out.printf("\nImpossibile,significa che avrebbe iniziato ad allenare a %d", diff);
						possibile = false;
					} else if (diff == 0) {
						System.out.println("Allenatore al suo primo anno di allenamento");
					}
				} while (possibile == false);
			} catch (Exception e) {
				System.out.println(e);
				err = true;
			}
		} while (err == true);
		return new Allenatore(nome, cognome, eta, esperienza);
	}

	public static void visualizzaAllenatore(Allenatore al) {
		System.out.println("Nome: " + al.getNome());
		System.out.println("Cognome: " + al.getCognome());
		System.out.println("Età: " + al.getEta());
		System.out.println("Anni di esperienza: " + al.getEsperienza());
	}

	public static void visualizzaRosa(Calciatore calciatori[], Calciatore portieri[], Calciatore difensori[],
			Calciatore centrocampisti[], Calciatore attaccanti[]) {
		System.out.println("Nome       Cognome        Ruolo          Numero   Età  Valutazione   Clausola");
		for (int i = 0; i < portieri.length; i++) {
			System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-6.2fmln\n", portieri[i].getNome(),
					portieri[i].getCognome(), portieri[i].getRuolo(), portieri[i].getNumero(), portieri[i].getEta(),
					portieri[i].getValutazione(), portieri[i].getValore());
		}
		for (int i = 0; i < difensori.length; i++) {
			System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-6.2fmln\n", difensori[i].getNome(),
					difensori[i].getCognome(), difensori[i].getRuolo(), difensori[i].getNumero(), difensori[i].getEta(),
					difensori[i].getValutazione(), difensori[i].getValore());
		}
		for (int i = 0; i < centrocampisti.length; i++) {
			System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-6.2fmln\n", centrocampisti[i].getNome(),
					centrocampisti[i].getCognome(), centrocampisti[i].getRuolo(), centrocampisti[i].getNumero(),
					centrocampisti[i].getEta(), centrocampisti[i].getValutazione(), centrocampisti[i].getValore());
		}
		for (int i = 0; i < attaccanti.length; i++) {
			System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-6.2fmln\n", attaccanti[i].getNome(),
					attaccanti[i].getCognome(), attaccanti[i].getRuolo(), attaccanti[i].getNumero(),
					attaccanti[i].getEta(), attaccanti[i].getValutazione(), attaccanti[i].getValore());
		}
	}

	public static void caricaSerieA(Squadra squadre[], Societa s) {
		int larghezzaNomeSquadra = 12;
		squadre[0] = new Squadra("Cagliari", 73.4f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[1] = new Squadra("Verona", 75.0f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[2] = new Squadra("Sassuolo", 76.7f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[3] = new Squadra("Empoli", 74.4f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[4] = new Squadra("Frosinone", 71.8f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[5] = new Squadra("Udinese", 75.6f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[6] = new Squadra("Lecce", 74.1f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[7] = new Squadra("Genoa", 74.5f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[8] = new Squadra("Monza", 76.1f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[9] = new Squadra("Torino", 76.8f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[10] = new Squadra("Napoli", 83.2f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[11] = new Squadra("Fiorentina", 78.9f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[12] = new Squadra("Lazio", 81.4f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[13] = new Squadra("Roma", 81.6f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[14] = new Squadra("Bologna", 76.5f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[15] = new Squadra("Atalanta", 79.6f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[16] = new Squadra("Milan", 82.5f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[17] = new Squadra("Juventus", 82.7f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[18] = new Squadra("Inter", 83.5f, 0, 0, 0, 0, 0, 0, 0, 0);
		squadre[19] = new Squadra(s.getNome(), valutazioneRosa, 0, 0, 0, 0, 0, 0, 0, 0);
		for (Squadra squadra : squadre) {
			String nomeSquadra = squadra.getNome();
			int spazi = larghezzaNomeSquadra - nomeSquadra.length();
			for (int i = 0; i < spazi; i++) {
				nomeSquadra += " ";
			}
			squadra.setNome(nomeSquadra);
		}
	}

	public static void visualizzaClassifica(Squadra avversari[]) {
		int cont = 0;
		System.out.println("    SQUADRA        PG    V    P    S   PT   GF   GS   DR");
		for (int i = avversari.length - 1; i >= 0; i--) {
			cont++;
			System.out.printf("%2d)", cont);
			System.out.printf(" " + avversari[i].getNome());
			System.out.printf("    " + avversari[i].getPartiteGiocate());
			System.out.printf("    " + avversari[i].getVittorie());
			System.out.printf("    " + avversari[i].getPareggi());
			System.out.printf("    " + avversari[i].getSconfitte());
			System.out.printf("    " + avversari[i].getPunti());
			System.out.printf("    " + avversari[i].getGolFatti());
			System.out.printf("    " + avversari[i].getGolSubiti());
			System.out.printf("    " + avversari[i].getDiffReti());
			System.out.println();
		}
	}

	public static void selezionaFormazione(Calciatore portieri[], Calciatore difensori[], Calciatore centrocampisti[],
			Calciatore attaccanti[], Calciatore titolari[], Calciatore calciatori[]) {
		valutazioneRosa = 0;
		int modulo = 0;
		boolean err = false;
		boolean scelta = false;
		do {
			scelta = false;
			do {
				err = false;
				try {
					System.out.println(
							"Inserisci uno dei moduli che preferisci tra quelli elencati tramite numero d'opzione:\n1)4-4-2\n2)4-3-3\n3)3-5-2\n4)3-4-3\n5)4-5-1");
					System.out.println(
							"NB. Alla fine dell'inserimento dell'undici titolare verrà calcolata la valutazione della tua squadra");
					modulo = in.nextInt();
				} catch (Exception e) {
					System.err.println(e);
					err = true;
				}
			} while (err == true);
			switch (modulo) {
			case 1:
				int contT = 0;
				try {
					System.out.println("Seleziona il portiere titolare tra questi inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int j = 0; j < portieri.length; j++) {
						System.out.printf("%d) ", j + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", portieri[j].getNome(),
								portieri[j].getCognome(), portieri[j].getRuolo(), portieri[j].getNumero(),
								portieri[j].getEta(), portieri[j].getValutazione(), portieri[j].getValore());
						System.out.println("");
					}
					int por = 0;
					do {
						por = in.nextInt();
					} while (por < 1 || por > 3);
					titolari[contT] = portieri[por - 1];
					valutazioneRosa += titolari[contT].getValutazione();
					contT++;
					System.out
							.println("Seleziona i 4 difensori tra quelli elencati inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int k = 0; k < difensori.length; k++) {
						System.out.printf("%d) ", k + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", difensori[k].getNome(),
								difensori[k].getCognome(), difensori[k].getRuolo(), difensori[k].getNumero(),
								difensori[k].getEta(), difensori[k].getValutazione(), difensori[k].getValore());
						System.out.println("");
					}
					int contDif = 0;
					do {
						boolean esiste = false;
						int dif = 0;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° difensore:", contDif + 1);
							dif = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (dif < 1 || dif > difensori.length || titolari[i] == difensori[dif - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = difensori[dif - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contDif++;
						contT++;
					} while (contDif < 4);
					System.out.println(
							"Seleziona i 4 centrocampisti tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int y = 0; y < centrocampisti.length; y++) {
						System.out.printf("%d) ", y + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", centrocampisti[y].getNome(),
								centrocampisti[y].getCognome(), centrocampisti[y].getRuolo(),
								centrocampisti[y].getNumero(), centrocampisti[y].getEta(),
								centrocampisti[y].getValutazione(), centrocampisti[y].getValore());
						System.out.println();
					}
					int contCen = 0;
					do {
						boolean esiste = false;
						int cen = 0;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° centrocampista:", contCen + 1);
							cen = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (cen < 1 || cen > centrocampisti.length || titolari[i] == centrocampisti[cen - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = centrocampisti[cen - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contCen++;
						contT++;
					} while (contCen < 4);
					System.out
							.println("Seleziona i 2 attaccanti tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int z = 0; z < attaccanti.length; z++) {
						System.out.printf("%d) ", z + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", attaccanti[z].getNome(),
								attaccanti[z].getCognome(), attaccanti[z].getRuolo(), attaccanti[z].getNumero(),
								attaccanti[z].getEta(), attaccanti[z].getValutazione(), attaccanti[z].getValore());
						System.out.println();
					}
					int contAtt = 0;
					do {
						int att = 0;
						boolean esiste = false;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° attaccante:", contAtt + 1);
							att = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (att < 1 || att > attaccanti.length || titolari[i] == attaccanti[att - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = attaccanti[att - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contAtt++;
						contT++;
					} while (contAtt < 2);

				} catch (Exception e) {
					System.err.println(e);
				}
				valutazioneRosa = valutazioneRosa / 11;
				System.out.printf("\nLa valutazione della tua rosa è pari: %.2f", valutazioneRosa);
				break;
			case 2:
				contT = 0;
				try {
					System.out.println("Seleziona il portiere titolare tra questi inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int j = 0; j < portieri.length; j++) {
						System.out.printf("%d) ", j + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", portieri[j].getNome(),
								portieri[j].getCognome(), portieri[j].getRuolo(), portieri[j].getNumero(),
								portieri[j].getEta(), portieri[j].getValutazione(), portieri[j].getValore());
						System.out.println("");
					}
					int por = 0;
					do {
						por = in.nextInt();
					} while (por < 1 || por > 3);
					titolari[contT] = portieri[por - 1];
					valutazioneRosa += titolari[contT].getValutazione();
					contT++;
					System.out
							.println("Seleziona i 4 difensori tra quelli elencati inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int k = 0; k < difensori.length; k++) {
						System.out.printf("%d) ", k + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", difensori[k].getNome(),
								difensori[k].getCognome(), difensori[k].getRuolo(), difensori[k].getNumero(),
								difensori[k].getEta(), difensori[k].getValutazione(), difensori[k].getValore());
						System.out.println("");
					}
					int contDif = 0;
					do {
						boolean esiste = false;
						int dif = 0;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° difensore:", contDif + 1);
							dif = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (dif < 1 || dif > difensori.length || titolari[i] == difensori[dif - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = difensori[dif - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contDif++;
						contT++;
					} while (contDif < 4);
					System.out.println(
							"Seleziona i 3 centrocampisti tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int y = 0; y < centrocampisti.length; y++) {
						System.out.printf("%d) ", y + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", centrocampisti[y].getNome(),
								centrocampisti[y].getCognome(), centrocampisti[y].getRuolo(),
								centrocampisti[y].getNumero(), centrocampisti[y].getEta(),
								centrocampisti[y].getValutazione(), centrocampisti[y].getValore());
						System.out.println();
					}
					int contCen = 0;
					do {
						boolean esiste = false;
						int cen = 0;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° centrocampista:", contCen + 1);
							cen = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (cen < 1 || cen > centrocampisti.length || titolari[i] == centrocampisti[cen - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = centrocampisti[cen - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contCen++;
						contT++;
					} while (contCen < 3);
					System.out
							.println("Seleziona i 3 attaccanti tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int z = 0; z < attaccanti.length; z++) {
						System.out.printf("%d) ", z + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", attaccanti[z].getNome(),
								attaccanti[z].getCognome(), attaccanti[z].getRuolo(), attaccanti[z].getNumero(),
								attaccanti[z].getEta(), attaccanti[z].getValutazione(), attaccanti[z].getValore());
						System.out.println();
					}
					int contAtt = 0;
					do {
						int att = 0;
						boolean esiste = false;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° attaccante:", contAtt + 1);
							att = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (att < 1 || att > attaccanti.length || titolari[i] == attaccanti[att - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = attaccanti[att - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contAtt++;
						contT++;
					} while (contAtt < 3);
				} catch (Exception e) {
					System.err.println(e);
				}
				valutazioneRosa = valutazioneRosa / 11;
				System.out.printf("\nLa valutazione della tua rosa è pari: %.2f", valutazioneRosa);
				break;
			case 3:
				contT = 0;
				try {
					System.out.println("Seleziona il portiere titolare tra questi inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int j = 0; j < portieri.length; j++) {
						System.out.printf("%d) ", j + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", portieri[j].getNome(),
								portieri[j].getCognome(), portieri[j].getRuolo(), portieri[j].getNumero(),
								portieri[j].getEta(), portieri[j].getValutazione(), portieri[j].getValore());
						System.out.println("");
					}
					int por = 0;
					do {
						por = in.nextInt();
					} while (por < 1 || por > 6);
					titolari[contT] = portieri[por - 1];
					valutazioneRosa += titolari[contT].getValutazione();
					contT++;
					System.out
							.println("Seleziona i 3 difensori tra quelli elencati inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int k = 0; k < difensori.length; k++) {
						System.out.printf("%d) ", k + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", difensori[k].getNome(),
								difensori[k].getCognome(), difensori[k].getRuolo(), difensori[k].getNumero(),
								difensori[k].getEta(), difensori[k].getValutazione(), difensori[k].getValore());
						System.out.println("");
					}
					int contDif = 0;
					do {
						boolean esiste = false;
						int dif = 0;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° difensore:", contDif + 1);
							dif = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (dif < 1 || dif > difensori.length || titolari[i] == difensori[dif - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = difensori[dif - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contDif++;
						contT++;
					} while (contDif < 3);
					System.out.println(
							"Seleziona i 5 centrocampisti tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int y = 0; y < centrocampisti.length; y++) {
						System.out.printf("%d) ", y + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", centrocampisti[y].getNome(),
								centrocampisti[y].getCognome(), centrocampisti[y].getRuolo(),
								centrocampisti[y].getNumero(), centrocampisti[y].getEta(),
								centrocampisti[y].getValutazione(), centrocampisti[y].getValore());
						System.out.println();
					}
					int contCen = 0;
					do {
						boolean esiste = false;
						int cen = 0;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° centrocampista:", contCen + 1);
							cen = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (cen < 1 || cen > centrocampisti.length || titolari[i] == centrocampisti[cen - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = centrocampisti[cen - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contCen++;
						contT++;
					} while (contCen < 5);
					System.out
							.println("Seleziona i 2 attaccanti tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int z = 0; z < attaccanti.length; z++) {
						System.out.printf("%d) ", z + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", attaccanti[z].getNome(),
								attaccanti[z].getCognome(), attaccanti[z].getRuolo(), attaccanti[z].getNumero(),
								attaccanti[z].getEta(), attaccanti[z].getValutazione(), attaccanti[z].getValore());
						System.out.println();
					}
					int contAtt = 0;
					do {
						int att = 0;
						boolean esiste = false;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° attaccante:", contAtt + 1);
							att = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (att < 1 || att > attaccanti.length || titolari[i] == attaccanti[att - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = attaccanti[att - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contAtt++;
						contT++;
					} while (contAtt < 2);
				} catch (Exception e) {
					System.err.println(e);
				}
				valutazioneRosa = valutazioneRosa / 11;
				System.out.printf("\nLa valutazione della tua rosa è pari: %.2f", valutazioneRosa);
				break;
			case 4:
				contT = 0;
				try {
					System.out.println("Seleziona il portiere titolare tra questi inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int j = 0; j < portieri.length; j++) {
						System.out.printf("%d) ", j + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", portieri[j].getNome(),
								portieri[j].getCognome(), portieri[j].getRuolo(), portieri[j].getNumero(),
								portieri[j].getEta(), portieri[j].getValutazione(), portieri[j].getValore());
						System.out.println("");
					}
					int por = 0;
					do {
						por = in.nextInt();
					} while (por < 1 || por > 3);
					titolari[contT] = portieri[por - 1];
					valutazioneRosa += titolari[contT].getValutazione();
					contT++;
					System.out
							.println("Seleziona i 3 difensori tra quelli elencati inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int k = 0; k < difensori.length; k++) {
						System.out.printf("%d) ", k + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", difensori[k].getNome(),
								difensori[k].getCognome(), difensori[k].getRuolo(), difensori[k].getNumero(),
								difensori[k].getEta(), difensori[k].getValutazione(), difensori[k].getValore());
						System.out.println("");
					}
					int contDif = 0;
					do {
						boolean esiste = false;
						int dif = 0;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° difensore:", contDif + 1);
							dif = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (dif < 1 || dif > difensori.length || titolari[i] == difensori[dif - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = difensori[dif - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contDif++;
						contT++;
					} while (contDif < 3);
					System.out.println(
							"Seleziona i 4 centrocampisti tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int y = 0; y < centrocampisti.length; y++) {
						System.out.printf("%d) ", y + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", centrocampisti[y].getNome(),
								centrocampisti[y].getCognome(), centrocampisti[y].getRuolo(),
								centrocampisti[y].getNumero(), centrocampisti[y].getEta(),
								centrocampisti[y].getValutazione(), centrocampisti[y].getValore());
						System.out.println();
					}
					int contCen = 0;
					do {
						boolean esiste = false;
						int cen = 0;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° centrocampista:", contCen + 1);
							cen = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (cen < 1 || cen > centrocampisti.length || titolari[i] == centrocampisti[cen - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = centrocampisti[cen - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contCen++;
						contT++;
					} while (contCen < 4);
					System.out
							.println("Seleziona i 3 attaccanti tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int z = 0; z < attaccanti.length; z++) {
						System.out.printf("%d) ", z + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", attaccanti[z].getNome(),
								attaccanti[z].getCognome(), attaccanti[z].getRuolo(), attaccanti[z].getNumero(),
								attaccanti[z].getEta(), attaccanti[z].getValutazione(), attaccanti[z].getValore());
						System.out.println();
					}
					int contAtt = 0;
					do {
						int att = 0;
						boolean esiste = false;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° attaccante:", contAtt + 1);
							att = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (att < 1 || att > attaccanti.length || titolari[i] == attaccanti[att - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = attaccanti[att - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contAtt++;
						contT++;
					} while (contAtt < 3);
				} catch (Exception e) {
					System.err.println(e);
				}
				valutazioneRosa = valutazioneRosa / 11;
				System.out.printf("\nLa valutazione della tua rosa è pari: %.2f", valutazioneRosa);
				break;
			case 5:
				contT = 0;
				try {
					System.out.println("Seleziona il portiere titolare tra questi inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int j = 0; j < portieri.length; j++) {
						System.out.printf("%d) ", j + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", portieri[j].getNome(),
								portieri[j].getCognome(), portieri[j].getRuolo(), portieri[j].getNumero(),
								portieri[j].getEta(), portieri[j].getValutazione(), portieri[j].getValore());
						System.out.println("");
					}
					int por = 0;
					do {
						por = in.nextInt();
					} while (por < 1 || por > 3);
					titolari[contT] = portieri[por - 1];
					valutazioneRosa += titolari[contT].getValutazione();
					contT++;
					System.out
							.println("Seleziona i 4 difensori tra quelli elencati inserendo il numero dato in elenco:");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int k = 0; k < difensori.length; k++) {
						System.out.printf("%d) ", k + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", difensori[k].getNome(),
								difensori[k].getCognome(), difensori[k].getRuolo(), difensori[k].getNumero(),
								difensori[k].getEta(), difensori[k].getValutazione(), difensori[k].getValore());
						System.out.println("");
					}
					int contDif = 0;
					do {
						boolean esiste = false;
						int dif = 0;
						do {
							System.out.printf("\nInserisci il %d° difensore:", contDif + 1);
							dif = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (dif < 1 || dif > difensori.length || titolari[i] == difensori[dif - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = difensori[dif - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contDif++;
						contT++;
					} while (contDif < 4);
					System.out.println(
							"Seleziona i 5 centrocampisti tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int y = 0; y < centrocampisti.length; y++) {
						System.out.printf("%d) ", y + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", centrocampisti[y].getNome(),
								centrocampisti[y].getCognome(), centrocampisti[y].getRuolo(),
								centrocampisti[y].getNumero(), centrocampisti[y].getEta(),
								centrocampisti[y].getValutazione(), centrocampisti[y].getValore());
						System.out.println();
					}
					int contCen = 0;
					do {
						boolean esiste = false;
						int cen = 0;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° centrocampista:", contCen + 1);
							cen = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (cen < 1 || cen > centrocampisti.length || titolari[i] == centrocampisti[cen - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = centrocampisti[cen - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contCen++;
						contT++;
					} while (contCen < 5);
					System.out.println("Seleziona l'attaccante tra quelli elencati inserendo il numero dato in elenco");
					System.out.println(
							"     Nome      Cognome     Ruolo            Numero   Età  Valutazione   Clausola");
					for (int z = 0; z < attaccanti.length; z++) {
						System.out.printf("%d) ", z + 1);
						System.out.printf("%-11s%-12s%-20s%-8d%-8d%-10d%-7.2fmln\n", attaccanti[z].getNome(),
								attaccanti[z].getCognome(), attaccanti[z].getRuolo(), attaccanti[z].getNumero(),
								attaccanti[z].getEta(), attaccanti[z].getValutazione(), attaccanti[z].getValore());
						System.out.println();
					}
					int contAtt = 0;
					do {
						int att = 0;
						boolean esiste = false;
						do {
							esiste = false;
							System.out.printf("\nInserisci il %d° attaccante:", contAtt + 1);
							att = in.nextInt();
							for (int i = 0; i < contT; i++) {
								if (att < 1 || att > attaccanti.length || titolari[i] == attaccanti[att - 1]) {
									esiste = true;
									break;
								}
							}
						} while (esiste);
						titolari[contT] = attaccanti[att - 1];
						valutazioneRosa += titolari[contT].getValutazione();
						contAtt++;
						contT++;
					} while (contAtt < 1);
				} catch (Exception e) {
					System.err.println(e);
				}
				valutazioneRosa = valutazioneRosa / 11;
				System.out.printf("\nLa valutazione della tua rosa è pari: %.2f", valutazioneRosa);
				break;
			default:
				System.out.println(
						"Opzione inserita non presente tra quelle elencate,inserisci il modulo tramite le opzioni:");
				scelta = true;
				break;
			}

		} while (scelta == true);
	}

	public static void simulaCampionato(Squadra squadre[]) {
		ArrayList<Squadra> team = new ArrayList<>(Arrays.asList(squadre));
		List<List<String>> calendario = generaAndata(team);
		System.out.println("Calendario di andata:");
		printCalendario(calendario);
		List<List<String>> calendarioRitorno = generaRitorno(calendario);
		System.out.println("\nCalendario di ritorno:");
		printCalendario(calendarioRitorno);
		simulaRisultati(calendario, team);
		simulaRisultati(calendarioRitorno, team);
	}

	public static Squadra castPartita(int j, int i, List<List<String>> calendario, ArrayList<Squadra> team, int pos) {
		String nomeSquadra = (calendario.get(j).get(i).split("vs")[pos]);
		for (Squadra sq : team) {
			if (nomeSquadra.equals(sq.getNome())) {
				return sq;
			}
		}
		return null;
	}

	public static void simulaRisultati(List<List<String>> calendario, ArrayList<Squadra> team) {
		System.out.println("Premi invio inziare la simulazione dalla prima giornata");
		for (int j = 0; j < 19; j++) {
			in.nextLine();
			System.out.printf("\n%d Giornata", j + 1);
			for (int i = 0; i < 10; i++) {
				Squadra squadraCasa = castPartita(j, i, calendario, team, 0);
				Squadra squadraOspite = castPartita(j, i, calendario, team, 1);
				float forzaCasa = squadraCasa.getValutazione();
				float forzaTrasferta = squadraOspite.getValutazione();
				float diffForza = forzaCasa - forzaTrasferta;
				int golCasa = 0, golTrasferta = 0;
				if (diffForza >= 5) {
					golCasa = (int) (Math.random() * 4) + 1;
					golTrasferta = (int) (Math.random() * 3);
				} else if (diffForza <= -5) {
					golCasa = (int) (Math.random() * 3);
					golTrasferta = (int) (Math.random() * 4) + 1;
				} else {
					golCasa = (int) (Math.random() * 5);
					golTrasferta = (int) (Math.random() * 5);
				}
				squadraCasa.aggiungiGolFatti(golCasa);
				squadraCasa.aggiungiGolSubiti(golTrasferta);
				squadraOspite.aggiungiGolFatti(golTrasferta);
				squadraOspite.aggiungiGolSubiti(golCasa);

				if (golCasa > golTrasferta) {
					squadraCasa.aggiungiPunti(3);
					squadraCasa.aggiungiVittorie();
					squadraOspite.aggiungiSconfitte();
				} else if (golCasa < golTrasferta) {
					squadraOspite.aggiungiPunti(3);
					squadraOspite.aggiungiVittorie();
					squadraCasa.aggiungiSconfitte();
				} else {
					squadraCasa.aggiungiPunti(1);
					squadraOspite.aggiungiPunti(1);
					squadraCasa.aggiungiPareggi();
					squadraOspite.aggiungiPareggi();
				}

				squadraCasa.aggiungiPartiteGiocate();
				squadraOspite.aggiungiPartiteGiocate();
				System.out.println();
				System.out.println(
						"" + squadraCasa.getNome() + "" + golCasa + "-" + golTrasferta + "" + squadraOspite.getNome());
			}
		}
	}

	public static List<List<String>> generaAndata(List<Squadra> squadre) {
		List<List<String>> calendario = new ArrayList<>();
		int numSquadre = squadre.size();

		List<Squadra> squadreCal = new ArrayList<>(squadre);
		for (int round = 0; round < numSquadre - 1; round++) {
			List<String> giornata = new ArrayList<>();
			for (int i = 0; i < numSquadre / 2; i++) {
				String squadraCasa = squadreCal.get(i).toString();
				String squadraTrasferta = squadreCal.get(numSquadre - 1 - i).toString();
				giornata.add(squadraCasa + "vs" + squadraTrasferta);
			}
			calendario.add(giornata);

			Squadra ultima = squadreCal.remove(squadreCal.size() - 1);
			squadreCal.add(1, ultima);
		}

		return calendario;
	}

	public static List<List<String>> generaRitorno(List<List<String>> calendarioAndata) {
		List<List<String>> calendarioRitorno = new ArrayList<>();
		for (List<String> giornata : calendarioAndata) {
			List<String> giornataRitorno = new ArrayList<>();
			for (String partita : giornata) {
				String[] teams = partita.split("vs");
				giornataRitorno.add(teams[1] + "vs" + teams[0]);
			}
			calendarioRitorno.add(giornataRitorno);
		}
		return calendarioRitorno;
	}

	public static void printCalendario(List<List<String>> calendario) {
		int giornataNumero = 1;
		for (List<String> giornata : calendario) {
			System.out.println("Giornata " + giornataNumero + ":");
			for (String partita : giornata) {
				System.out.println("  " + partita);
			}
			giornataNumero++;
		}
	}

	public static void vediClassifica(Squadra squadre[]) {
		System.out.println("Classifica alla fine della 38° giornata di Serie A");
		for (int i = 0; i < squadre.length; i++) {
			for (int j = i + 1; j < squadre.length; j++) {
				if (squadre[i].getPunti() < squadre[j].getPunti()) {
					Squadra t = squadre[i];
					squadre[i] = squadre[j];
					squadre[j] = t;
				}
			}
		}
		for (int i = 0; i < squadre.length; i++) {
			System.out.printf("%3d %s  PG: %2d, V: %2d, P: %2d, S: %2d, GF: %3d, GS: %3d, DR: %3d, PT: %2d\n", i + 1,
					squadre[i].getNome(), squadre[i].getPartiteGiocate(), squadre[i].getVittorie(),
					squadre[i].getPareggi(), squadre[i].getSconfitte(), squadre[i].getGolFatti(),
					squadre[i].getGolSubiti(), squadre[i].getDiffReti(), squadre[i].getPunti());
		}
	}

	public static void vediFormazione(Calciatore titolari[]) {
		System.out.println("11 TITOLARE:");
		System.out.println("RUOLO                NOME      COGNOME   NUMERO   ETA'  VALUTAZIONE  CLAUSOLA");
		for (int i = 0; i < titolari.length; i++) {
			System.out.printf("%-20s%-11s%-12s%-8d%-8d%-10d%-5.2fmln\n", titolari[i].getRuolo(), titolari[i].getNome(),
					titolari[i].getCognome(), titolari[i].getNumero(), titolari[i].getEta(),
					titolari[i].getValutazione(), titolari[i].getValore());
		}
	}
}

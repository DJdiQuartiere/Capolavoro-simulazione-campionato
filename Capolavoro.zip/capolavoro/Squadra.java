package capolavoro;

public class Squadra {
	private String nome;
	private float valutazione;
	private int partiteGiocate,vittorie,pareggi,sconfitte,punti,golFatti,golSubiti,diffReti;
	public Squadra(String nome, float valutazione, int partiteGiocate, int vittorie, int pareggi, int sconfitte,int punti,int golFatti,int golSubiti, int diffReti) {
		this.nome = nome;
		this.valutazione = valutazione;
		this.partiteGiocate = partiteGiocate;
		this.vittorie = vittorie;
		this.pareggi = pareggi;
		this.sconfitte = sconfitte;
		this.punti = punti;
		this.golFatti=golFatti;
		this.golSubiti=golSubiti;
		this.diffReti = diffReti;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getValutazione() {
		return valutazione;
	}
	public void setValutazione(float valutazione) {
		this.valutazione = valutazione;
	}
	public int getPartiteGiocate() {
		return partiteGiocate;
	}
	public void setPartiteGiocate(int partiteGiocate) {
		this.partiteGiocate = partiteGiocate;
	}
	public int getVittorie() {
		return vittorie;
	}
	public void setVittorie(int vittorie) {
		this.vittorie = vittorie;
	}
	public int getPareggi() {
		return pareggi;
	}
	public void setPareggi(int pareggi) {
		this.pareggi = pareggi;
	}
	public int getSconfitte() {
		return sconfitte;
	}
	public void setSconfitte(int sconfitte) {
		this.sconfitte = sconfitte;
	}
	public int getPunti() {
		return punti;
	}
	public void setPunti(int punti) {
		this.punti = punti;
	}
	public int getDiffReti() {
		return diffReti;
	}
	public void setDiffReti(int diffReti) {
		this.diffReti = diffReti;
	}
	public int getGolFatti() {
		return golFatti;
	}
	public void setGolFatti(int golFatti) {
		this.golFatti = golFatti;
	}
	public int getGolSubiti() {
		return golSubiti;
	}
	public void setGolSubiti(int golSubiti) {
		this.golSubiti = golSubiti;
	}
	
	public void aggiungiGolFatti(int gol) {
		golFatti+=gol;
		diffReti += gol;
	}
	public void aggiungiGolSubiti(int gol) {
		golSubiti+=gol;
		diffReti-= gol;
	}
	public void aggiungiVittorie() {
		vittorie++;
	}
	public void aggiungiPareggi() {
		pareggi++;
	}
	public void aggiungiSconfitte() {
		sconfitte++;
	}
	
	public void aggiungiPartiteGiocate() {
		partiteGiocate++;
	}
	
	public void aggiungiPunti(int punti) {
		this.punti+=punti;
	}
	
	public String toString() {
		return nome+"";
	}
}

package capolavoro;

public class Calciatore {
	private String nome,cognome,ruolo;
	private int eta,numero,valutazione;
	private float valore;
	
	public Calciatore(String nome, String cognome,String ruolo, int numero, int eta,int valutazione, float valore) {
		this.nome = nome;
		this.cognome = cognome;
		this.ruolo = ruolo;
		this.numero = numero;
		this.eta = eta;
		this.valutazione = valutazione;
		this.valore = valore;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getRuolo() {
		return ruolo;
	}

	public void setRuolo(String ruolo) {
		this.ruolo = ruolo;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getEta() {
		return eta;
	}

	public void setEta(int eta) {
		this.eta = eta;
	}

	public int getValutazione() {
		return valutazione;
	}

	public void setValutazione(int valutazione) {
		this.valutazione = valutazione;
	}

	public float getValore() {
		return valore;
	}

	public void setValore(float valore) {
		this.valore = valore;
	}
	
	public String toString() {
		return " "+nome+" "+cognome+" "+ruolo+" "+numero+" "+eta+" "+valutazione+" "+valore;
	}
	
}

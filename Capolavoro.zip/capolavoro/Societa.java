package capolavoro;

public class Societa {
	private String nome,soprannome,sede,stadio;
	private int capienzaStadio;
	
	public Societa(String nome, String soprannome, String sede, String stadio,int capienzaStadio) {
		this.nome = nome;
		this.soprannome = soprannome;
		this.sede = sede;
		this.stadio = stadio;
		this.capienzaStadio = capienzaStadio;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSoprannome() {
		return soprannome;
	}

	public void setSoprannome(String soprannome) {
		this.soprannome = soprannome;
	}

	public String getSede() {
		return sede;
	}

	public void setSede(String sede) {
		this.sede = sede;
	}

	public String getStadio() {
		return stadio;
	}

	public void setStadio(String stadio) {
		this.stadio = stadio;
	}

	public int getCapienzaStadio() {
		return capienzaStadio;
	}

	public void setCapienzaStadio(int capienzaStadio) {
		this.capienzaStadio = capienzaStadio;
	}
	
	public String toString() {
		return " "+nome+" "+soprannome+" "+sede+" "+stadio+" "+capienzaStadio;
	}
		
}
